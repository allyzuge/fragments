package com.example.assignment_02;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list first_fragment = new list();
        getSupportFragmentManager().beginTransaction().add(R.id.first_fragment,first_fragment).commit();

    }
}