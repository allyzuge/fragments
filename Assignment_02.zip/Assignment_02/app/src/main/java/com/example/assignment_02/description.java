package com.example.assignment_02;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class description extends Fragment {
    View fragment2;
    TextView description;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        fragment2 = inflater.inflate(R.layout.fragment_description, container, false);

        description = fragment2.findViewById(R.id.park_desc);

        return fragment2;
    }

    public void setString(String descStr){
        description.setText(descStr);
    }
}