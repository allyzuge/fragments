package com.example.assignment_02;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;


public class list extends Fragment {
    View fragment1;
    ListView park_list;
    String[] nationalparks;
    String[] desc;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragment1 = inflater.inflate(R.layout.fragment_list, container, false);

        park_list  = fragment1.findViewById(R.id.nt_parks);

        nationalparks = getResources().getStringArray(R.array.national_parks);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireActivity().getApplicationContext(), android.R.layout.simple_list_item_1, nationalparks);

        park_list.setAdapter(adapter);

        park_list.setOnItemClickListener((adapterView, view, i, l) -> {
            desc = getResources().getStringArray(R.array.park_description);
            description desc_fragment = (description)getFragmentManager().findFragmentById(R.id.second_fragment);
            desc_fragment.setString(desc[i]);
        });

        return fragment1;
    }
}